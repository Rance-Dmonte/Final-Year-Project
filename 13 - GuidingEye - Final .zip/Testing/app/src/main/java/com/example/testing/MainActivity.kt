package com.example.testing

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.example.testing.LanguageHelper.language
import com.example.testing.LanguageHelper.languageCode
import com.example.testing.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var viewBinding: ActivityMainBinding

    // if u r using a camera controller
    private lateinit var cameraController: LifecycleCameraController
    // if using camera provider
    private var imageCapture: ImageCapture? = null
    val scope: CoroutineScope = CoroutineScope(Dispatchers.Main)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Toast.makeText(getApplicationContext(), language + " selected", Toast.LENGTH_SHORT).show();

        val textToSpeechHelper = (application as MyApplication).getTextToSpeechHelper()
        textToSpeechHelper.setLanguage(languageCode)




        viewBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        // to check if required permissions were granted in a previous session
        if (!hasPermissions(baseContext)){
            // request camera-related permissions
            activityResultLauncher.launch(REQUIRED_PERMISSIONS)
        }
        else{
            scope.launch {
                startCamera()
                // Code before delay
//                delay(750) // Delay for 3 seconds
                // Code after delay
//                takePhoto()
            }
        }
//        viewBinding.imageCaptureButton.setOnClickListener{ takePhoto() }
    }

    private fun startCamera(){
        val previewView: PreviewView = viewBinding.viewFinder
        cameraController = LifecycleCameraController(baseContext)
        cameraController.bindToLifecycle(this)
        cameraController.cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA  // default BACK camera
        previewView.controller = cameraController
    }

    private fun takePhoto() {
        val executor = ContextCompat.getMainExecutor(this)
        cameraController.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {

            override fun onCaptureSuccess(image: ImageProxy) {
//                Toast.makeText(this@MainActivity, "Photo captured", Toast.LENGTH_LONG).show()
                val rotationDegrees = image.imageInfo.rotationDegrees
                val imageBuffer = image.planes[0].buffer
                val imageBytes = ByteArray(imageBuffer.remaining())
                imageBuffer.get(imageBytes)

                // Create a temporary file in the cache directory
                val imageFile = File(cacheDir, "tempImage.jpg")

                // Correct image orientation if needed
                val rotatedBitmap = rotateImage(BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size), rotationDegrees)
                val rotatedOutputStream = FileOutputStream(imageFile)
                rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 50, rotatedOutputStream)
                rotatedOutputStream.close()

                Log.d(TAG, "Photo captured and saved successfully: ${imageFile.path}")

                // Update UI with the information in the TextView (tvResult)
                val tvResult = findViewById<TextView>(R.id.tvResult)
                val alerts = findViewById<TextView>(R.id.alerts)

                RoboflowAPI(applicationContext, tvResult, alerts).execute()
                image.close()
            }
            override fun onError(exception: ImageCaptureException) {
                Log.e(TAG, "Photo capture failed: ${exception.message}", exception)
            }
        })
    }

    private fun rotateImage(source: Bitmap, angle: Int): Bitmap {
        val matrix = Matrix()
        matrix.postRotate(angle.toFloat())
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }



    private val activityResultLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){
            permissions ->
            // andle permission granted/rejected
            var permissionGranted = true
            permissions.entries.forEach{
                if(it.key in REQUIRED_PERMISSIONS && it.value == false)
                    permissionGranted = false
            }
            if(!permissionGranted){
                Toast.makeText(this, "Permission request denied", Toast.LENGTH_LONG).show()
            }
            else{
                startCamera()
            }
        }

    companion object{
        private const val TAG = "CameraXApp"    // APP NAME
        private const val FILENAME_FORMAT= "yyyy-MM-dd-HH-mm-ss-SSS"    // to name saved images
        private val REQUIRED_PERMISSIONS =
            mutableListOf(
                android.Manifest.permission.CAMERA
            ).apply{
                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P){
                    add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                }
            }.toTypedArray()
        // following checks if permissions have already been granted
        fun hasPermissions(context: Context) = REQUIRED_PERMISSIONS.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }


        // to hande images that are rotated

    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            // Volume up button pressed
            takePhoto()
            return true
        } else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            // Volume down button pressed
            takePhoto()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}