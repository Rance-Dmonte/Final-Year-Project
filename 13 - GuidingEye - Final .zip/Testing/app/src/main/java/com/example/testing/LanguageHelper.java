package com.example.testing;

public class LanguageHelper {
    public static String language = "English"; // Declare language variable here
    public static String languageCode="en";
}