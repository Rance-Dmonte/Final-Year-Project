package com.example.testing;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.HashMap;


public class LanguageSelectionActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_SPEECH_INPUT = 1000;
//    TextView mTextTv;
    HashMap<String, String> languages = new HashMap<>();
    private TextToSpeechHelper textToSpeechHelper;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_selection);


        languages.put("english", "en");
        languages.put("hindi", "hi");
        languages.put("marathi", "mr");


        // Get the existing instance of TextToSpeechHelper from the main activity
        textToSpeechHelper = ((MyApplication) getApplicationContext()).getTextToSpeechHelper();
        textToSpeechHelper.speak("Please select a language to continue.");
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Call the speak method after 2 seconds delay
                speak();
            }
        }, 2000);



        Button englishButton = findViewById(R.id.englishButton);
        Button hindiButton = findViewById(R.id.hindiButton);
        Button marathiButton = findViewById(R.id.marathiButton);
        Button mVoiceBtn = findViewById(R.id.speak);

//        mTextTv = findViewById(R.id.speech_to_text_result);

        englishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setLanguage("English", "en");
                startActivity(new Intent(LanguageSelectionActivity.this, MainActivity.class));
            }
        });

        hindiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setLanguage("Hindi", "hi");
                startActivity(new Intent(LanguageSelectionActivity.this, MainActivity.class));
            }
        });

        marathiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setLanguage("Marathi", "mr");
                startActivity(new Intent(LanguageSelectionActivity.this, MainActivity.class));
            }
        });

        mVoiceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                speak();
            }
        });
    }

    private void setLanguage(String language, String languageCode) {
        LanguageHelper.language = language;
        LanguageHelper.languageCode = languageCode;
    }

    // func to check if the spoken sentence has a languages in it
    public boolean containsLanguage(String input) {

        // Split the input string into words
        String[] words = input.split("\\s+"); // Split by whitespace

        // Convert both arrays to lowercase for case-insensitive comparison
//        String[] lowercaseLanguages = Arrays.stream(languages)
//                .map(String::toLowerCase)
//                .toArray(String[]::new);
        String[] lowercaseWords = Arrays.stream(words)
                .map(String::toLowerCase)
                .toArray(String[]::new);

        // Check if any of the words in the input match the languages array
        for (String word : lowercaseWords) {
            if (languages.containsKey(word)) {
//                Toast.makeText(this, "Language: "+word, Toast.LENGTH_SHORT).show();
                setLanguage(word, languages.get(word));
                textToSpeechHelper.speak(word + " selected");
                startActivity(new Intent(LanguageSelectionActivity.this, MainActivity.class));
                return true; // Found a match
            }
        }
        return false; // No match found
    }


    private void speak() {
        // intent to show speech to text dialog
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);

        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Hi speak something");

        // start intent
        try{
            // if there was no error
            // show dialog

            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);
        }
        catch(Exception e){
            // if there was some error
            // get message of error and show

            Toast.makeText(this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch(requestCode){
            case REQUEST_CODE_SPEECH_INPUT:{
                if (resultCode == RESULT_OK && null!=data){
                    // GET TEXT ARRAY FROM VOICE INTENT
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    // set to text view

//                    mTextTv.setText(result.get(0));
                    containsLanguage(result.get(0));
                }
                break;
            }
        }
    }


    // for calling text to speech

    @Override
    protected void onDestroy() {
        if (textToSpeechHelper != null) {
            textToSpeechHelper.shutdown();
        }
        super.onDestroy();
    }

    // Example of using the TextToSpeechHelper
    private void speakText(String text) {
        if (textToSpeechHelper != null) {
            Toast.makeText(this, "entered tts", Toast.LENGTH_SHORT).show();
            textToSpeechHelper.speak(text);
        }
        else{
            Toast.makeText(this, "Text to speech not available", Toast.LENGTH_SHORT).show();
        }
    }

}

