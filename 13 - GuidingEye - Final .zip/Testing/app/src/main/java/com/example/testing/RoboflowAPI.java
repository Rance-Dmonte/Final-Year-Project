package com.example.testing;


import static android.content.ContentValues.TAG;

import static androidx.camera.core.impl.utils.ContextUtil.getApplicationContext;
import static com.example.testing.LanguageHelper.language;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import android.util.Base64;
import java.util.Locale;

import android.os.AsyncTask;
import android.util.Log;
import android.speech.tts.TextToSpeech;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class RoboflowAPI extends AsyncTask<Void, Void, String>{
    private static final String TAG = "ImageProcessingTask";

    private Context context;
    private TextView tvResult;
    private TextView alerts;
    private TextToSpeech textToSpeech;
    private String convertedText; // Declare convertedText variable
    private TextToSpeechHelper textToSpeechHelper;  // tts

    // Constructor to receive the context and views
    public RoboflowAPI(Context context, TextView tvResult, TextView alerts) {
        Log.d("roboflow_debug", "constructor called");
        this.context = context;
        this.tvResult = tvResult;
        this.alerts = alerts;
    }




    @Override
    protected String doInBackground(Void... params) {
        try {
            // Assuming you have the file name
            String fileName = "tempImage.jpg";

            // Create a File object for the image in the cache directory
            File imageFile = new File(context.getCacheDir(), fileName);

            if (imageFile.exists()) {
                // Create OkHttp client
                OkHttpClient client = new OkHttpClient();

                // Create request body
                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("file", fileName,
                                RequestBody.create(MediaType.parse("image/jpeg"), imageFile))
                        .build();

                // Build the request
                Request request = new Request.Builder()
                        .url("https://0ef4-35-187-251-150.ngrok-free.app/upload")
                        .post(requestBody)
                        .build();

                // Execute the request
                try (Response response = client.newCall(request).execute()) {
                    if (!response.isSuccessful()) {
                        throw new IOException("Unexpected code " + response);
                    }
                    return response.body().string();
                }
            } else {
                Log.e(TAG, "Image file not found in the cache directory");
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.e(TAG, "Error in HTTP request: " + e.getMessage());
        }
        return null;
    }

    // Method to read file contents as bytes
    private byte[] readFileBytes(File file) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        FileInputStream fis = new FileInputStream(file);
        byte[] buffer = new byte[1024];
        int bytesRead;
        while ((bytesRead = fis.read(buffer)) != -1) {
            bos.write(buffer, 0, bytesRead);
        }
        fis.close();
        return bos.toByteArray();
    }




    @Override
    protected void onPostExecute(String result) {

        Log.d("roboflow_debug", "entered postexecute!");
        // Handle the result, update UI, etc.
        if (result != null) {
            Log.d("debug tag", "result: " + result);
            try {
                // Parse the JSON response
//                JSONObject jsonResponse = new JSONObject(result);

                // Extract information from the response
//                double time = jsonResponse.optDouble("time");
//                JSONObject imageInfo = jsonResponse.optJSONObject("image");
//                int width = imageInfo.optInt("width");
//                int height = imageInfo.optInt("height");

//                JSONArray predictions = jsonResponse.optJSONArray("predictions");

                // Construct a display message
//                StringBuilder displayMessage = new StringBuilder(String.format(Locale.getDefault(),
//                        "Time: %.2f seconds\nImage Size: %dx%d\nNumber of Predictions: %d\n",
//                        time, width, height, predictions.length()));


                // Extract classes and other details from predictions
//                for (int i = 0; i < predictions.length(); i++) {
//                    JSONObject prediction = predictions.optJSONObject(i);
//                    if (prediction != null) {
//                        double confidence = prediction.optDouble("confidence");
//                        String className = prediction.optString("class", "");
//                        String formattedPrediction = String.format(Locale.getDefault(),
//                                "%s (%.2f)", className, confidence);
//                        displayMessage.append(String.format(Locale.getDefault(),
//                                "Prediction %d: %s\n", i + 1, formattedPrediction));
//                    }
//                }
                // Log the display message
                Log.d("API Response", result);

                // Update UI with the information in the TextView (tvResult)
//                TextView tvResult = findViewById(R.id.tvResult);
//                tvResult.setText(displayMessage.toString());


                //// FOR ALERTS:

//                ObjectDetectionHelper helper = new ObjectDetectionHelper();
//                JSONArray predictionsArray = predictions;
                String alertText = result;
//                Log.d("DEBUG", "onPostExecute: reached the alert section");

//                if (predictionsArray != null && predictionsArray.length() > 0) {
//                    for (int i = 0; i < predictionsArray.length(); i++) {
//                        Log.d("DEBUG", "onPostExecute: reached here bf call: iteration 1 " + predictionsArray.optJSONObject(i));
//
//                        JSONObject prediction = predictionsArray.optJSONObject(i);
//
//                        // Call the method with appropriate arguments
//                        String resultText = helper.processPrediction(prediction, width, height);
//
//                        // Print or use the result as needed
//                        System.out.println("Result for Prediction " + (i + 1) + ": " + resultText);
//                        alertText = alertText + resultText + "\n";
//                    }
//                } else {
//                    System.out.println("No predictions found in the data.");
//                }

//                TextView alerts = findViewById(R.id.alerts);




                // PERFORMING THE CONVERSION

                convertedText = alertText; // Default to the original text
                if (!"English".equalsIgnoreCase(language)) {
                    // Only convert if the language is not English
                    TextConverter textConverter = new TextConverter(context);
                    textConverter.setInputAndLanguage(alertText, language);
                    convertedText = textConverter.convertText();
                }


                alerts.setText(convertedText);

                // read the text out loud
                textToSpeechHelper = ((MyApplication) context).getTextToSpeechHelper();
                textToSpeechHelper.speak(convertedText);





            } catch (Exception e) {
                e.printStackTrace();
                Log.e("JSON Parsing Error", "Error parsing JSON response");
            }
        } else {
            // Your error handling code
            Log.e("API Error", "Error making API call");
        }
    }



    @Override
    protected void onCancelled() {
        super.onCancelled();

        // Release TextToSpeech resources
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
    }

}


