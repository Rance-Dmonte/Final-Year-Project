package com.example.testing;

import android.app.Application;
import com.example.testing.TextToSpeechHelper;

import java.util.HashMap;
import java.util.Map;

public class MyApplication extends Application {
    private TextToSpeechHelper textToSpeechHelper;
    private Map<String, TextToSpeechHelper> ttsHelpers = new HashMap<>();


    @Override
    public void onCreate() {
        super.onCreate();
        textToSpeechHelper = TextToSpeechHelper.getInstance(getApplicationContext());
    }

    public TextToSpeechHelper getTextToSpeechHelper() {
        return textToSpeechHelper;
    }
}
