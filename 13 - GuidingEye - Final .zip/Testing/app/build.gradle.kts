plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.testing"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.testing"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    buildFeatures{
        viewBinding = true
    }
    packaging {
        resources {
            excludes.add("project.properties")
            excludes.add("META-INF/INDEX.LIST")
        }
//        jniLibs {
//            excludes.add("**/*.so")
//        }
    }
}

configurations {
    all {
        exclude(group = "com.google.guava", module = "listenablefuture")
        exclude(group = "com.google.auto.value", module= "auto-value-annotations")
    }
}

dependencies {

    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.concurrent:concurrent-futures:1.1.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.4.0")

    implementation("com.google.cloud:google-cloud-translate:1.12.0") {
        exclude(group = "org.apache.httpcomponents")
        exclude(group = "org.json", module = "json")
    }
    annotationProcessor("com.google.cloud:google-cloud-translate:1.12.0")

//    adding dependencies for camerax
    val camerax_version: String by project  // most stable version
    implementation("androidx.camera:camera-core:${camerax_version}")    //
    implementation("androidx.camera:camera-camera2:${camerax_version}")
    implementation("androidx.camera:camera-view:${camerax_version}")   // to get cameraxs preview
    implementation("androidx.camera:camera-lifecycle:${camerax_version}")
    implementation("androidx.camera:camera-view:1.3.1")   // for camera provider
    implementation("pl.droidsonroids.gif:android-gif-drawable:1.2.19") // for gif splash screen
    implementation("com.google.android.gms:play-services-tasks:17.2.1")     // for text to speech
    implementation("com.squareup.okhttp3:okhttp:4.9.3") // Replace with the latest version




    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")

}